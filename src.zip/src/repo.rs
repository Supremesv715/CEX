use crate::db::DbPool;
use rust_decimal::Decimal;
use uuid::Uuid;
use sqlx::Row;

pub async fn create_user(pool: &DbPool, user_id: Uuid, username: &str) -> Result<(), sqlx::Error> {
    sqlx::query("INSERT INTO users (id, username, metadata) VALUES ($1, $2, $3)")
        .bind(user_id)
        .bind(username)
        .bind(serde_json::Value::Null)
        .execute(pool)
        .await?;
    Ok(())
}

pub async fn upsert_balance(
    pool: &DbPool,
    user_id: Uuid,
    asset: &str,
    available: Decimal,
    locked: Decimal,
) -> Result<(), sqlx::Error> {
    sqlx::query(
        "INSERT INTO balances (user_id, asset, available, locked) VALUES ($1, $2, $3, $4)
         ON CONFLICT (user_id, asset) DO UPDATE SET available = EXCLUDED.available, locked = EXCLUDED.locked, updated_at = now()",
    )
    .bind(user_id)
    .bind(asset)
    .bind(available)
    .bind(locked)
    .execute(pool)
    .await?;
    Ok(())
}

pub async fn insert_order(
    pool: &DbPool,
    id: Uuid,
    user_id: Uuid,
    side: &str,
    order_type: &str,
    status: &str,
    price: Option<Decimal>,
    amount: Decimal,
) -> Result<(), sqlx::Error> {
    sqlx::query("INSERT INTO orders (id, user_id, side, order_type, status, price, amount, filled) VALUES ($1,$2,$3,$4,$5,$6,$7,$8)")
        .bind(id)
        .bind(user_id)
        .bind(side)
        .bind(order_type)
        .bind(status)
        .bind(price)
        .bind(amount)
        .bind(Decimal::new(0,0))
        .execute(pool)
        .await?;
    Ok(())
}

pub async fn insert_trade(
    pool: &DbPool,
    id: Uuid,
    buy_order_id: Option<Uuid>,
    sell_order_id: Option<Uuid>,
    price: Decimal,
    amount: Decimal,
) -> Result<(), sqlx::Error> {
    sqlx::query("INSERT INTO trades (id, buy_order_id, sell_order_id, price, amount) VALUES ($1,$2,$3,$4,$5)")
        .bind(id)
        .bind(buy_order_id)
        .bind(sell_order_id)
        .bind(price)
        .bind(amount)
        .execute(pool)
        .await?;
    Ok(())
}



pub async fn increment_order_filled(
    pool: &DbPool,
    order_id: Uuid,
    delta: Decimal,
) -> Result<(Decimal, String), sqlx::Error> {
    

    let row = sqlx::query("UPDATE orders SET filled = filled + $1, status = CASE WHEN (filled + $1) >= amount THEN 'filled' WHEN (filled + $1) > 0 THEN 'partially_filled' ELSE status END, updated_at = now() WHERE id = $2 RETURNING filled, status")
        .bind(delta)
        .bind(order_id)
        .fetch_one(pool)
        .await?;

    let filled: Decimal = row.try_get("filled")?;
    let status: String = row.try_get("status")?;
    Ok((filled, status))
}





pub async fn lock_balance(
    pool: &DbPool,
    user_id: Uuid,
    asset: &str,
    amount: Decimal,
) -> Result<(Decimal, Decimal), String> {
    let row = sqlx::query("UPDATE balances SET available = available - $1, locked = locked + $1, updated_at = now() WHERE user_id = $2 AND asset = $3 AND available >= $1 RETURNING available, locked")
        .bind(amount)
        .bind(user_id)
        .bind(asset)
        .fetch_optional(pool)
        .await
        .map_err(|e| e.to_string())?;

    if let Some(r) = row {
        let available: Decimal = r.try_get("available").map_err(|e| e.to_string())?;
        let locked: Decimal = r.try_get("locked").map_err(|e| e.to_string())?;
        Ok((available, locked))
    } else {
        Err(format!("Insufficient available balance for asset: {}", asset))
    }
}

pub async fn insert_ledger(
    pool: &DbPool,
    user_id: Uuid,
    asset: &str,
    delta: Decimal,
    balance_before: Decimal,
    balance_after: Decimal,
    reason: &str,
    related_order: Option<Uuid>,
) -> Result<(), sqlx::Error> {
    sqlx::query("INSERT INTO ledger (user_id, asset, delta, balance_before, balance_after, reason, related_order, created_at) VALUES ($1,$2,$3,$4,$5,$6,$7, now())")
        .bind(user_id)
        .bind(asset)
        .bind(delta)
        .bind(balance_before)
        .bind(balance_after)
        .bind(reason)
        .bind(related_order)
        .execute(pool)
        .await?;
    Ok(())
}

pub struct UserRow {
    pub id: Uuid,
    pub username: String,
}

pub async fn load_users(pool: &DbPool) -> Result<Vec<UserRow>, sqlx::Error> {
    let rows = sqlx::query("SELECT id, username FROM users").fetch_all(pool).await?;
    let mut out = Vec::new();
    for r in rows {
        let id: Uuid = r.try_get("id")?;
        let username: String = r.try_get("username")?;
        out.push(UserRow { id, username });
    }
    Ok(out)
}

pub struct BalanceRow {
    pub user_id: Uuid,
    pub asset: String,
    pub available: Decimal,
    pub locked: Decimal,
}

pub async fn load_balances(pool: &DbPool) -> Result<Vec<BalanceRow>, sqlx::Error> {
    let rows = sqlx::query("SELECT user_id, asset, available, locked FROM balances").fetch_all(pool).await?;
    let mut out = Vec::new();
    for r in rows {
        let user_id: Uuid = r.try_get("user_id")?;
        let asset: String = r.try_get("asset")?;
        let available: Decimal = r.try_get("available")?;
        let locked: Decimal = r.try_get("locked")?;
        out.push(BalanceRow { user_id, asset, available, locked });
    }
    Ok(out)
}

use serde::Serialize;

#[derive(Serialize)]
pub struct OrderRow {
    pub id: Uuid,
    pub user_id: Uuid,
    pub side: String,
    pub order_type: String,
    pub status: String,
    pub price: Option<Decimal>,
    pub amount: Decimal,
    pub market: Option<String>,
}

pub async fn load_open_orders(pool: &DbPool) -> Result<Vec<OrderRow>, sqlx::Error> {
    let rows = sqlx::query("SELECT id, user_id, side, order_type, status, price, amount, market FROM orders WHERE status IN ('open','partially_filled')").fetch_all(pool).await?;
    let mut out = Vec::new();
    for r in rows {
        let id: Uuid = r.try_get("id")?;
        let user_id: Uuid = r.try_get("user_id")?;
        let side: String = r.try_get("side")?;
        let order_type: String = r.try_get("order_type")?;
        let status: String = r.try_get("status")?;
        let price: Option<Decimal> = r.try_get("price")?;
        let amount: Decimal = r.try_get("amount")?;
        let market: Option<String> = r.try_get("market")?;
        out.push(OrderRow { id, user_id, side, order_type, status, price, amount, market });
    }
    Ok(out)
}

pub async fn get_order(pool: &DbPool, id: Uuid) -> Result<Option<OrderRow>, sqlx::Error> {
    let r = sqlx::query("SELECT id, user_id, side, order_type, status, price, amount, market FROM orders WHERE id = $1")
        .bind(id)
        .fetch_optional(pool)
        .await?;
        
    if let Some(r) = r {
        Ok(Some(OrderRow {
            id: r.try_get("id")?,
            user_id: r.try_get("user_id")?,
            side: r.try_get("side")?,
            order_type: r.try_get("order_type")?,
            status: r.try_get("status")?,
            price: r.try_get("price")?,
            amount: r.try_get("amount")?,
            market: r.try_get("market")?,
        }))
    } else {
        Ok(None)
    }
}

pub async fn update_order_status(pool: &DbPool, id: Uuid, status: &str) -> Result<(), sqlx::Error> {
    sqlx::query("UPDATE orders SET status = $1, updated_at = now() WHERE id = $2")
        .bind(status)
        .bind(id)
        .execute(pool)
        .await?;
    Ok(())
}

pub async fn insert_price_snapshot(
    pool: &DbPool,
    base: &str,
    quote: &str,
    price: rust_decimal::Decimal,
    fetched_at: chrono::DateTime<chrono::Utc>,
    source: Option<&str>,
) -> Result<(), sqlx::Error> {
    sqlx::query("INSERT INTO prices (base, quote, price, fetched_at, source, created_at) VALUES ($1,$2,$3,$4,$5, now())")
        .bind(base)
        .bind(quote)
        .bind(price)
        .bind(fetched_at)
        .bind(source)
        .execute(pool)
        .await?;
    Ok(())
}
